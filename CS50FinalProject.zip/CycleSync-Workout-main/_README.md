# PROJECT TITLE: CycleSync Workout
#### Video Demo:  <URL HERE TBC>
#### Description:

A web application that generates personalized workout plans based on the user's menstrual cycle phase and fitness level.

## Features
- Select menstrual cycle phase and fitness level
- Automatically generates a 3-part workout based on the database:
  1. Warm-up
  2. Main workout (30–50 minutes, matches phase + level)
  3. Cool-down/stretch
- Embeds YouTube videos directly from the `youtube_id` column
- Responsive, clean, feminine design

## Technologies
Technologies Used
- Backend: Python, Flask
- Frontend: HTML5, CSS3, JavaScript
- Design: Responsive CSS
- SQLite database (`workouts.db`)
- CS50 library

## Database Schema
The workouts.db contains a single table with the following columns:
id: Unique identifier
youtube_id: YouTube video ID
name: Workout title
duration: Duration in minutes
cycle_phase: menstrual, follicular, ovulation, luteal
fitness_level: beginner, sporty
type: HIIT, yoga, warmup, stretch
channel: YouTube channel name
