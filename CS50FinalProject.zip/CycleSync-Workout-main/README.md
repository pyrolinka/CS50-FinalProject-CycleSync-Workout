# CycleSync Workout Application

A web-based application that generates personalized workouts based on menstrual cycle phases and fitness levels.

## Features

- Generates workout plans tailored to different menstrual cycle phases:
  - **Menstrual**: Gentle, restorative movement (single video)
  - **Follicular**, **Ovulation**, **Luteal**: Complete workouts with warmup, main exercises, and cool-down
- Supports different fitness levels (Beginner, Sporty)
- Database of YouTube workout videos
- Responsive web interface

## Setup Instructions

### Prerequisites
- Python 3 installed on your system
- SQLite3 (comes with Python)

### Installation

1. **Clone or download the project files**

2. **Create a virtual environment:**
   ```bash
   python3 -m venv venv
   ```

3. **Activate the virtual environment:**
   - On macOS/Linux:
     ```bash
     source venv/bin/activate
     ```
   - On Windows:
     ```bash
     venv\Scripts\activate
     ```

4. **Install Flask:**
   ```bash
   pip install flask
   ```

5. **Run the application:**
   ```bash
   python app.py
   ```

6. **Open your web browser and go to:**
   ```
   http://127.0.0.1:5000
   ```

## How to Use

1. Select your current menstrual cycle phase from the dropdown
2. Select your fitness level (Beginner or Sporty)
3. Click "Generate My Workout"
4. View your personalized workout plan with embedded YouTube videos

## Project Structure

```
CycleSync-Workout/
├── app.py              # Flask backend application
├── workouts.db         # SQLite database with workout videos
├── venv/              # Virtual environment folder
├── templates/         # HTML templates
│   └── index.html     # Main web page
└── static/            # Static files
    ├── css/
    │   └── styles.css # Styling
    └── js/
        └── script.js  # JavaScript functionality
```

## Database Schema

The `workouts` table contains:
- `id`: Unique identifier
- `youtube_id`: YouTube video URL
- `name`: Workout title
- `duration_min`: Duration in minutes
- `cycle_phase`: Target phase (menstrual, follicular, ovulation, luteal, or all)
- `fitness_level`: Target level (beginner, sporty, or all)
- `type`: Workout type (warmup, stretch, weight, body weight, etc.)
- `channel`: YouTube channel name

## Troubleshooting

If you encounter any errors:

1. **ModuleNotFoundError**: Make sure you've activated the virtual environment and installed Flask
2. **Database errors**: Ensure `workouts.db` is in the same directory as `app.py`
3. **Port already in use**: The app uses port 5000 by default. If it's occupied, you can change it in `app.py`

## Technologies Used

- **Backend**: Python with Flask
- **Frontend**: HTML, CSS, JavaScript
- **Database**: SQLite3
- **Videos**: YouTube API integration